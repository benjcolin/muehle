package sample.controller;

import javafx.stage.Stage;

/**
 * Created by Stuber Gregor on 07.07.2016.
 */
public class Controller1vsKI {

    public Controller1vsKI(Stage stage){

    }
}
